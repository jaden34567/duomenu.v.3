# DuoMenu
A duolingo extension hack.

## ⚠ Warning!
the intent of this project is educational, exploring resources and learning from them. I am not responsible for any acts against those I mentioned.

## ✅ A duolingo hack, 100% free.
With this extension you can skip all questions and gain ingots and xp quickly.

## 💡 How to install

### Extension:
![tutorial](https://i.imgur.com/85wbUzd.gif)

Almost ready! Now, you need to host the server that will handle the hack.

## Node.js Server

I will be using [repl.it](https://replit.com/), a free hosting platform.

https://user-images.githubusercontent.com/81244634/130856664-be140c96-e187-46c5-873c-5be7cd99a5da.mp4

Done! Now you can **start** the extension and try it out!
![img](https://i.imgur.com/Y2kOwjh.jpg)


## 🐞 Possible errors


- **Error: Server unavailable or invalid URL!**
This error only happens if the server is down, or you didn't configure it correctly, or you entered the wrong url.
It is recommended to check the tutorial above again.
- **loading infinitely**
Try to go back to the duolingo menu and start the lesson again, if it persists, check if the server is turned on.
